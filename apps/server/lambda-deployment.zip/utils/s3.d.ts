export interface FileUploadParams {
    fileName: string;
    fileType: string;
    fileSize: number;
    userId: string;
    conversationId?: string;
    personaId?: string;
}
export interface PresignedUrlResponse {
    fileId: string;
    presignedUrl: string;
    s3Key: string;
    s3Url: string;
    expiresIn: number;
}
export declare function generatePresignedUrl(params: FileUploadParams): Promise<PresignedUrlResponse>;
export declare function getMediaType(mimeType: string): string;
export declare function validateFileUpload(file: {
    size: number;
    type: string;
    name: string;
}): {
    valid: boolean;
    error?: string;
};
//# sourceMappingURL=s3.d.ts.map