import serverless from "serverless-http";
declare const handler: serverless.Handler;
export { handler };
//# sourceMappingURL=lambda.d.ts.map