import express from "express";
export declare const router: <TProcRouterRecord extends import("@trpc/server").ProcedureRouterRecord>(procedures: TProcRouterRecord) => import("@trpc/server").CreateRouterInner<import("@trpc/server").RootConfig<{
    ctx: {
        req: express.Request;
        res: express.Response;
    };
    meta: object;
    errorShape: import("@trpc/server").DefaultErrorShape;
    transformer: import("@trpc/server").DefaultDataTransformer;
}>, TProcRouterRecord>;
export declare const publicProcedure: import("@trpc/server").ProcedureBuilder<{
    _config: import("@trpc/server").RootConfig<{
        ctx: {
            req: express.Request;
            res: express.Response;
        };
        meta: object;
        errorShape: import("@trpc/server").DefaultErrorShape;
        transformer: import("@trpc/server").DefaultDataTransformer;
    }>;
    _ctx_out: {
        req: express.Request;
        res: express.Response;
    };
    _input_in: typeof import("@trpc/server").unsetMarker;
    _input_out: typeof import("@trpc/server").unsetMarker;
    _output_in: typeof import("@trpc/server").unsetMarker;
    _output_out: typeof import("@trpc/server").unsetMarker;
    _meta: object;
}>;
export declare const appRouter: import("@trpc/server").CreateRouterInner<import("@trpc/server").RootConfig<{
    ctx: {
        req: express.Request;
        res: express.Response;
    };
    meta: object;
    errorShape: import("@trpc/server").DefaultErrorShape;
    transformer: import("@trpc/server").DefaultDataTransformer;
}>, {
    hello: import("@trpc/server").BuildProcedure<"query", {
        _config: import("@trpc/server").RootConfig<{
            ctx: {
                req: express.Request;
                res: express.Response;
            };
            meta: object;
            errorShape: import("@trpc/server").DefaultErrorShape;
            transformer: import("@trpc/server").DefaultDataTransformer;
        }>;
        _ctx_out: {
            req: express.Request;
            res: express.Response;
        };
        _input_in: typeof import("@trpc/server").unsetMarker;
        _input_out: typeof import("@trpc/server").unsetMarker;
        _output_in: typeof import("@trpc/server").unsetMarker;
        _output_out: typeof import("@trpc/server").unsetMarker;
        _meta: object;
    }, {
        message: string;
    }>;
    auth: import("@trpc/server").CreateRouterInner<import("@trpc/server").RootConfig<{
        ctx: {
            req: express.Request;
            res: express.Response;
        };
        meta: object;
        errorShape: import("@trpc/server").DefaultErrorShape;
        transformer: import("@trpc/server").DefaultDataTransformer;
    }>, {
        register: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                req: express.Request;
                res: express.Response;
            };
            _input_in: {
                name: string;
                email: string;
                password: string;
            };
            _input_out: {
                name: string;
                email: string;
                password: string;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            user: {
                id: string;
                email: string;
                name: string;
                createdAt: string;
            };
            token: string;
        }>;
        login: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                req: express.Request;
                res: express.Response;
            };
            _input_in: {
                email: string;
                password: string;
            };
            _input_out: {
                email: string;
                password: string;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            user: {
                id: string;
                email: string;
                name: string;
                createdAt: string;
            };
            token: string;
        }>;
        me: import("@trpc/server").BuildProcedure<"query", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: typeof import("@trpc/server").unsetMarker;
            _input_out: typeof import("@trpc/server").unsetMarker;
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            id: string;
            email: string;
            name: string;
            createdAt: string;
        }>;
    }>;
    personas: import("@trpc/server").CreateRouterInner<import("@trpc/server").RootConfig<{
        ctx: {
            req: express.Request;
            res: express.Response;
        };
        meta: object;
        errorShape: import("@trpc/server").DefaultErrorShape;
        transformer: import("@trpc/server").DefaultDataTransformer;
    }>, {
        list: import("@trpc/server").BuildProcedure<"query", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: typeof import("@trpc/server").unsetMarker;
            _input_out: typeof import("@trpc/server").unsetMarker;
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            userId: string;
            name: string;
            description: string | null;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            traits: Record<string, any> | null;
            preferences: Record<string, any> | null;
            isDefault: boolean | null;
            avatar: string | null;
        }[]>;
        create: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                name: string;
                description?: string | undefined;
            };
            _input_out: {
                name: string;
                description?: string | undefined;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            userId: string;
            name: string;
            description: string | null;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            traits: Record<string, any> | null;
            preferences: Record<string, any> | null;
            isDefault: boolean | null;
            avatar: string | null;
        }>;
        get: import("@trpc/server").BuildProcedure<"query", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                id: string;
            };
            _input_out: {
                id: string;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            userId: string;
            name: string;
            description: string | null;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            traits: Record<string, any> | null;
            preferences: Record<string, any> | null;
            isDefault: boolean | null;
            avatar: string | null;
        }>;
        update: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                id: string;
                data: {
                    name?: string | undefined;
                    description?: string | undefined;
                };
            };
            _input_out: {
                id: string;
                data: {
                    name?: string | undefined;
                    description?: string | undefined;
                };
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            userId: string;
            name: string;
            description: string | null;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            traits: Record<string, any> | null;
            preferences: Record<string, any> | null;
            isDefault: boolean | null;
            avatar: string | null;
        }>;
        delete: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                id: string;
            };
            _input_out: {
                id: string;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            success: boolean;
        }>;
    }>;
    chat: import("@trpc/server").CreateRouterInner<import("@trpc/server").RootConfig<{
        ctx: {
            req: express.Request;
            res: express.Response;
        };
        meta: object;
        errorShape: import("@trpc/server").DefaultErrorShape;
        transformer: import("@trpc/server").DefaultDataTransformer;
    }>, {
        conversations: import("@trpc/server").BuildProcedure<"query", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: typeof import("@trpc/server").unsetMarker;
            _input_out: typeof import("@trpc/server").unsetMarker;
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            userId: string;
            personaId: string | null;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            title: string | null;
            isActive: boolean | null;
        }[]>;
        createConversation: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                personaId?: string | undefined;
                title?: string | undefined;
            };
            _input_out: {
                personaId?: string | undefined;
                title?: string | undefined;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            userId: string;
            personaId: string | null;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            title: string | null;
            isActive: boolean | null;
        }>;
        getMessages: import("@trpc/server").BuildProcedure<"query", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                conversationId: string;
            };
            _input_out: {
                conversationId: string;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            metadata: Record<string, any> | null;
            conversationId: string;
            content: string;
            role: "user" | "assistant" | "system";
            id: string;
            createdAt: Date;
        }[]>;
        sendMessage: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                conversationId: string;
                content: string;
                role: "user" | "assistant" | "system";
            };
            _input_out: {
                conversationId: string;
                content: string;
                role: "user" | "assistant" | "system";
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            metadata: Record<string, any> | null;
            conversationId: string;
            content: string;
            role: "user" | "assistant" | "system";
            id: string;
            createdAt: Date;
        }>;
    }>;
    social: import("@trpc/server").CreateRouterInner<import("@trpc/server").RootConfig<{
        ctx: {
            req: express.Request;
            res: express.Response;
        };
        meta: object;
        errorShape: import("@trpc/server").DefaultErrorShape;
        transformer: import("@trpc/server").DefaultDataTransformer;
    }>, {
        connections: import("@trpc/server").BuildProcedure<"query", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: typeof import("@trpc/server").unsetMarker;
            _input_out: typeof import("@trpc/server").unsetMarker;
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            userId: string;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            isActive: boolean | null;
            platform: "twitter" | "instagram" | "facebook" | "linkedin" | "tiktok";
            platformUserId: string;
            accessToken: string | null;
            refreshToken: string | null;
            platformUsername: string | null;
            tokenExpiry: Date | null;
            lastSync: Date | null;
        }[]>;
        connect: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                platform: "twitter" | "instagram" | "facebook" | "linkedin" | "tiktok";
                platformUserId: string;
                accessToken: string;
                username?: string | undefined;
                refreshToken?: string | undefined;
            };
            _input_out: {
                platform: "twitter" | "instagram" | "facebook" | "linkedin" | "tiktok";
                platformUserId: string;
                accessToken: string;
                username?: string | undefined;
                refreshToken?: string | undefined;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            userId: string;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            isActive: boolean | null;
            platform: "twitter" | "instagram" | "facebook" | "linkedin" | "tiktok";
            platformUserId: string;
            accessToken: string | null;
            refreshToken: string | null;
            platformUsername: string | null;
            tokenExpiry: Date | null;
            lastSync: Date | null;
        }>;
        disconnect: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                id: string;
            };
            _input_out: {
                id: string;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            success: boolean;
        }>;
    }>;
    media: import("@trpc/server").CreateRouterInner<import("@trpc/server").RootConfig<{
        ctx: {
            req: express.Request;
            res: express.Response;
        };
        meta: object;
        errorShape: import("@trpc/server").DefaultErrorShape;
        transformer: import("@trpc/server").DefaultDataTransformer;
    }>, {
        requestPresignedUrl: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                fileName: string;
                fileType: string;
                fileSize: number;
                conversationId?: string | undefined;
                personaId?: string | undefined;
            };
            _input_out: {
                fileName: string;
                fileType: string;
                fileSize: number;
                conversationId?: string | undefined;
                personaId?: string | undefined;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            fileId: string;
            presignedUrl: string;
            s3Key: string;
            expiresIn: number;
        }>;
        updateFileStatus: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                fileId: string;
                status: "pending" | "completed" | "deleted" | "failure" | "archived";
                uploadedAt?: Date | undefined;
            };
            _input_out: {
                fileId: string;
                status: "pending" | "completed" | "deleted" | "failure" | "archived";
                uploadedAt?: Date | undefined;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            success: boolean;
        }>;
        getFilesByConversation: import("@trpc/server").BuildProcedure<"query", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                conversationId: string;
            };
            _input_out: {
                conversationId: string;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, Record<string, unknown>[]>;
        getUserFiles: import("@trpc/server").BuildProcedure<"query", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: typeof import("@trpc/server").unsetMarker;
            _input_out: typeof import("@trpc/server").unsetMarker;
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, Record<string, unknown>[]>;
        deleteFile: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                fileId: string;
            };
            _input_out: {
                fileId: string;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            success: boolean;
        }>;
        restoreFile: import("@trpc/server").BuildProcedure<"mutation", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                fileId: string;
            };
            _input_out: {
                fileId: string;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            success: boolean;
        }>;
        getFileDetails: import("@trpc/server").BuildProcedure<"query", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                fileId: string;
            };
            _input_out: {
                fileId: string;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, Record<string, unknown>>;
        getAllUserFiles: import("@trpc/server").BuildProcedure<"query", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: {
                limit?: number | undefined;
                offset?: number | undefined;
                includeDeleted?: boolean | undefined;
                mediaType?: string | undefined;
            };
            _input_out: {
                limit: number;
                offset: number;
                includeDeleted: boolean;
                mediaType?: string | undefined;
            };
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            files: Record<string, unknown>[];
            total: any;
            hasMore: boolean;
        }>;
        getFileStats: import("@trpc/server").BuildProcedure<"query", {
            _config: import("@trpc/server").RootConfig<{
                ctx: {
                    req: express.Request;
                    res: express.Response;
                };
                meta: object;
                errorShape: import("@trpc/server").DefaultErrorShape;
                transformer: import("@trpc/server").DefaultDataTransformer;
            }>;
            _meta: object;
            _ctx_out: {
                user: {
                    name: string;
                    image: string | null;
                    email: string;
                    id: string;
                    passwordHash: string | null;
                    emailVerified: Date | null;
                    createdAt: Date;
                    updatedAt: Date;
                };
                req: express.Request<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
                res: express.Response<any, Record<string, any>>;
            };
            _input_in: typeof import("@trpc/server").unsetMarker;
            _input_out: typeof import("@trpc/server").unsetMarker;
            _output_in: typeof import("@trpc/server").unsetMarker;
            _output_out: typeof import("@trpc/server").unsetMarker;
        }, {
            total_files: number;
            completed_files: number;
            pending_files: number;
            deleted_files: number;
            image_files: number;
            video_files: number;
            document_files: number;
            total_size: number;
        }>;
    }>;
}>;
export type AppRouter = typeof appRouter;
//# sourceMappingURL=router.d.ts.map