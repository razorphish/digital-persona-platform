import { handler } from "./lambda.js";
export { handler };
export default handler;
//# sourceMappingURL=index-lambda.d.ts.map